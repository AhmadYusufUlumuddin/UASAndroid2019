package com.AhmadYusuf.uas;

public class Konfigurasi {

    public static final String URL_ADD = "http://192.168.43.47/form/tambah.php";
    public static final String URL_GET_ALL = "http://192.168.43.47/form/lihat.php";

    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAMA = "nama";
    public static final String KEY_EMP_NIM = "nik";
    public static final String KEY_EMP_ALAMAT = "jam";
    public static final String KEY_EMP_JENISKELAMIN = "kelas";


    public static final String KEY_ID = "id";
    public static final String KEY_SUKA = "suka";

    public static final String TAG_Id = "id";
    public static final String TAG_SUKA = "suka";

    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_NIM = "nik";
    public static final String TAG_ALAMAT = "jam";
    public static final String TAG_JENISKELAMIN = "kelas";

    public static final String EMP_ID = "emp_id";
    public static final String EMP_NAMA = "emp_nama";
}